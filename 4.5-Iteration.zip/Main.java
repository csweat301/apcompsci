import labs.*;

public class Main {

	public static void main(String[] args) {
		NESTE_3 neste = new NESTE_3();
		
		neste.go();
	}

}